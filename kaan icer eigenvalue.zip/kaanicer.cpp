#include<iostream>
#include<fstream>
#include<new>
#include<string>
#include<stdlib.h>
#include<math.h>
#include<cmath>
using namespace std;

double absolute_value(double p){ // this function returns the absolute value of a number.
	if(p<0){
		p=(-1)*p;
	}
	else{
		p=p;
	}
	return p;
}

double max_element_finder(double *y, int size){ // this function returns the element which has the maximum absolute value...
	double max_number=0;						//normally absolute value is returned for normalized power iteration...
	int num;									//but it gives the absolute value of eigenvalue, i returned the element itself...
	for(int i=0; i<size; i++){					//to find eigenvalue with sign.
		if(absolute_value(y[i])>=max_number){
			max_number=absolute_value(y[i]);
			num=i;
		}
		else{
			max_number=max_number;
		}
	}
	return y[num];
}

int main(int argc, char* argv[]){
	
	ifstream mymatrixfile; //to read the matrix file, I wrote ifstream
	
	double **array1, **array2, **array3, **array4, **householder, **arrayb, *x, *y, *v, *new_x, *new_y;
	
	string matrixfile, outputfile, d;
	double tolerance_value; //input by user.
	int do_the_operations=0;
	
	d=argv[0];
	if(argc>1){matrixfile=argv[1];}
	if(argc>2){tolerance_value=atof(argv[2]);}
	if(argc>3){outputfile=argv[3];}
	
	string line;
	int size=0;
	mymatrixfile.open(matrixfile.c_str()); //here I open the file of matrix and evaluate the size of the n*n matrix by passing the lines.
	if(mymatrixfile.is_open()){
	while(getline(mymatrixfile, line)){
		size++;
	}
	mymatrixfile.close();
	do_the_operations=1;
	}
	else{
		cout<<"unable to open matrix file."<<endl;
	}
	
	array1= new double* [size]; //dynamic allocation of matrix 
	for(int i=0; i<size; i++){
		array1[i]= new double [size];
		}
	array2= new double* [size]; //dynamic allocation of matrix 
	for(int i=0; i<size; i++){
		array2[i]= new double [size];
		}
	array3= new double* [size]; //dynamic allocation of matrix 
	for(int i=0; i<size; i++){
		array3[i]= new double [size];
		}
	array4= new double* [size]; //dynamic allocation of matrix 
	for(int i=0; i<size; i++){
		array4[i]= new double [size];
		}
	householder= new double* [size]; //dynamic allocation of matrix 
	for(int i=0; i<size; i++){
		householder[i]= new double [size];
		}
	arrayb= new double* [size-1]; //dynamic allocation of matrix 
	for(int i=0; i<size-1; i++){
		arrayb[i]= new double [size-1];
		}
			
	x= new double[size]; //dynamic allocation of starting vector for normalized power iteration method
	for(int i=0; i<size; i++){
		if(i%2==0){
			x[i]=1;
		}
		else{
			x[i]=0.6;
		}
	}
	y= new double[size]; //dynamic allocation of "y" vector for normalized power iteration method (Ax=y)
	new_x= new double[size-1]; //dynamic allocation of starting vector for deflation
	for(int i=0; i<size-1; i++){
		if(i%2==0){
			new_x[i]=1;
		}
		else{
			new_x[i]=0.6;
		}
	}
	new_y= new double[size-1]; //dynamic allocation of "y" vector for deflation
	v= new double[size]; //dynamic allocation of "v" vector for deflation during householder transformation
	
	double number;
	mymatrixfile.open(matrixfile.c_str()); //here I open the matrix file to read the matrix... 
	int k=0, f=0;						   //to put the elements of the matrix into an array properly, I used while loop. 
	if(mymatrixfile.is_open()){			   //while loop takes the elements of the matrix until the last element of the file.
	while(mymatrixfile>>number){		   //array1 becomes the matrix.
		array1[k][f]=number;
		while(f==size-1){
			f=-1;
			k++;
		}
		f++;
	}
	mymatrixfile.close();
	}
	
	double max_element=0,max_element2=0, previous_max_element, sum, norm_of_x, alpha, scalar;
	if(do_the_operations==1){ //if the file is opened in which n*n matrix exists, normalized power iteration will start.
		do{
			for(int i=0; i<size; i++){ //this part products matrix and vector.
				sum=0;
				for(int j=0; j<size; j++){
					sum=sum+(array1[i][j]*x[j]);	
				}
				y[i]=sum;
			}
			previous_max_element=max_element; //previous_max_element holds previous eigenvalue.
			max_element=max_element_finder(y, size); //this part finds the element with max. abs. value
			for(int i=0; i<size; i++){ //this part normalizes the vector.
				x[i]=y[i]/max_element;
			}
		}while(absolute_value(max_element-previous_max_element)>tolerance_value); //when the difference between the last 2 eigenvalues are smaller than...
																				  //tolerance value it means eigenvalue converged and operations can finish.
		cout<<"Eigenvalue#1: "<<max_element<<endl; //here i printed out the eigenvalue and eigenvector onto the screen.
		for(int i=0; i<size; i++){
			cout<<x[i]<<endl;
		}
		
		sum=0;
		for(int i=0; i<size; i++){ //here second norm of vector is taken.
			sum=sum+(x[i]*x[i]);
		}
		norm_of_x=sqrt(sum);
		if(x[0]<0){               //here sign is determined for vector used for householder transformation.
			alpha=norm_of_x;
		}
		else{
			alpha=(-1)*norm_of_x;
		}
		v[0]=x[0]-alpha;         //here vector v is determined to generate householder matrix.
		for(int i=1; i<size; i++){
			v[i]=x[i];
		}
		scalar=0;
		for(int i=0; i<size; i++){
			scalar=scalar+(v[i]*v[i]);
		}
		for(int i=0; i<size; i++){	// here householder matrix is generated.
			for(int j=0; j<size; j++){
				array2[i][j]=(2*v[i]*v[j])/scalar;
			}
		}
		for(int i=0; i<size; i++){
			for(int j=0; j<size; j++){
				if(i==j){
					array2[i][j]=array2[i][j]-1;
				}
			}
		}
		for(int i=0; i<size; i++){
			for(int j=0; j<size; j++){
				householder[i][j]=(-1)*array2[i][j];
			}
		}
		sum=0;
		for(int i=0; i<size; i++){	//here HA product is done.
			for(int j=0; j<size; j++){
				sum=0;
				for(int k=0; k<size; k++){
					sum=sum+(householder[i][k]*array1[k][j]);
				}
				array3[i][j]=sum;
			}
		}
		sum=0;
		for(int i=0; i<size; i++){	//here (HA)H^(-1) product is done.
			for(int j=0; j<size; j++){
				sum=0;
				for(int k=0; k<size; k++){
					sum=sum+(array3[i][k]*householder[k][j]);
				}
				array4[i][j]=sum;
			}
		}
		for(int i=0; i<size-1; i++){	//here second matrix (n-1)*(n-1) is taken to find second dominant eigenvalue, process called deflation.
			for(int j=0; j<size-1; j++){
				arrayb[i][j]=array4[i+1][j+1];
			}
		}
		max_element2=0;
		do{
			for(int i=0; i<size-1; i++){	//this part products matrix and vector.
				sum=0;
				for(int j=0; j<size-1; j++){
					sum=sum+(arrayb[i][j]*new_x[j]);	
				}
				new_y[i]=sum;
			}
			previous_max_element=max_element2; //previous_max_element holds previous eigenvalue.
			max_element2=max_element_finder(new_y, size-1); //this part finds the element with max. abs. value
			for(int i=0; i<size-1; i++){	//this part normalizes the vector.
				new_x[i]=new_y[i]/max_element2;
			}		
		}while(absolute_value(max_element2-previous_max_element)>tolerance_value);
		
		cout<<"Eigenvalue#2: "<<max_element2<<endl; //here i printed out the second dominant eigenvalue.
		ofstream myoutputfile; //I wrote "ofstream" to create a file in which file the solutions are written.
		myoutputfile.open(outputfile.c_str()); //here i write the all results into a .txt file which's name is determined by user.
		myoutputfile<<"Eigenvalue#1: "<<max_element<<endl;
		for(int i=0; i<size; i++){
			myoutputfile<<x[i]<<endl;
		}
		myoutputfile<<"Eigenvalue#2: "<<max_element2<<endl;
		myoutputfile.close();
	}	
	
	for(int i=0; i<size; i++){ //I deleted the array1 to avoid memory loss.
		delete [] array1[i];	
    }
    delete[]array1;
    for(int i=0; i<size; i++){ //I deleted the array2 to avoid memory loss.
		delete [] array2[i];	
    }
    delete[]array2;
    for(int i=0; i<size; i++){ //I deleted the array3 to avoid memory loss.
		delete [] array3[i];	
    }
    delete[]array3;
    for(int i=0; i<size; i++){ //I deleted the array4 to avoid memory loss.
		delete [] array4[i];	
    }
    delete[]array4;
    for(int i=0; i<size; i++){ //I deleted the householder to avoid memory loss.
		delete [] householder[i];	
    }
    delete[]householder;
    for(int i=0; i<size-1; i++){ //I deleted the arrayb to avoid memory loss.
		delete [] arrayb[i];	
    }
    delete[]arrayb;
    
    delete[]x; //I deleted the x to avoid memory loss.
    delete[]y; //I deleted the y to avoid memory loss.
    delete[]v; //I deleted the v to avoid memory loss.
    
	return 0;
}
