Kaan icer 2017401072
* My project evaluates the 2 dominant eigenvalues of n*n matrix...
(n should be greater than or equal to 2) and eigenvector corresponding... 
to dominant eigenvalue by using normalized power iteration method...
with deflation.
*You should first compile .cpp file to create .exe file.
(you will compile kaanicer.cpp and by doing that you generate kaanicer.exe)
*You should use command prompt to run the code.
*How to use command prompt?
     1) you need to reach the file kaanicer.exe, on prompt you should go 
        where this file is. (e.g. if the file is located on desktop,
        you need to go desktop etc.)
     2) when you reach the location, you need to write the file name and
        inputs like this: kaanicer.exe matrixfile.txt 0.000001 result.txt  
        (here matrixfile is the name of the matrix file, 0.000001 is the
        tolerance value, result is the file showing the results.)
     3) then you need to run the code. You will see the outputs on the
	command prompt, also there will be an output file showing the same
	results. (above at "2)" the name of the output file is result, but
	you can choose any other names.)
*How the outputs will be like?
--> Outputs will be like below:
Eigenvalue#1: 4.89 // it is the dominant eigenvalue.
0.47 // [0.47 1 -0.89] is eigenvector corresponding to Eigenvalue#1.
1
-0.89
Eigenvalue#2: -3.129 // it is the second dominant eigenvalue.  
*Warnings:
--> When you entered the wrong file name for matrix file, you will get
    warning like "unable to open matrix file."
--> Do not forget to add .txt to end of the matrix file name and result 
    file name. 
--> This method works only for real numbers.